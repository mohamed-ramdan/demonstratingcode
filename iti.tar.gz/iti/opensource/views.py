from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from .models import Student

def allStudents(request):
	all_students = Student.objects.all()
	context = {"allStudents": all_students}
	return render(request, "student/all_st.html", context)

def getStudent(request, st_id):
	st = Student.objects.get(id = st_id)
	context = {"student":st }
	return render(request, "student/st_details.html", context)