from django.contrib import admin
from .models import Student, Track

# Register your models here.

class CustomStudent(admin.ModelAdmin):
	fieldsets = (
		["Personal Information", {"fields":["full_name", "age"]}],
		["Scholarship Information", {"fields": ["student_track"]}]

		)
	list_display = ["full_name", "age", "student_track", "is_senior_student"]
	list_filter = ["full_name"]
	search_fields = ("full_name","student_track__track_name")

class InlineStudent(admin.StackedInline):
	model = Student
	extra = 3

class CustomTrack(admin.ModelAdmin):
	inlines = [InlineStudent]

admin.site.register(Student, CustomStudent)
admin.site.register(Track, CustomTrack)
