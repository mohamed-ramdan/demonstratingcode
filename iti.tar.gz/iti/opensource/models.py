from django.db import models

# Create your models here.

class Track(models.Model):
	track_name = models.CharField(max_length= 50)
	def __str__(self):
		return self.track_name

class Student(models.Model):
	full_name = models.CharField(max_length= 20)
	age = models.IntegerField()
	student_track = models.ForeignKey(Track)

	def __str__(self):
		return self.full_name

	def is_senior_student(self):
		if self.age > 50:
			return True
		else:
			return False
	is_senior_student.boolean = True
	is_senior_student.short_description = "Senior ?"
