from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^allstudents/$', views.allStudents),
    url(r'^(?P<st_id>[0-9]+)$',  views.getStudent)

    
]
